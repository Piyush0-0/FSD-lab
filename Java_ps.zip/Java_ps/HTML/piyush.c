#include <stdio.h>
int mutex=1,pos=-1,buffer[10];
int main() 
{
    int p,q;
    while (1)
    {
        printf("Here are the options\n1.produce\n2.consume\n3.exit\n\nEnter your choice:");
        scanf("%d",&p);
        if (p==1)
        {
            if (pos==9)
            {
                printf("Buffer is full!!\n");
            }
            else
            {
                printf("enter the value:");
                scanf("%d",&q);
                pos++;
                buffer[pos]=q;
            }
        }
        else if (p==2)
        {
            if (pos==-1)
            {
                printf("Buffer is Empty!!\n");
            }
            else
            {
                printf("Element %d is consumed\n",buffer[pos]);
                pos--;
            }
        }
        else
        {
            break;
        }
    }
}