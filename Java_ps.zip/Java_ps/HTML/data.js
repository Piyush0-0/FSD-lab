// const mailData = ['piyush', 'shree', 'mahi'];
// const passData = ['1234', '4321', '54'];
var ppp=10;
function fun1() {
    var email = document.getElementById('mail').value;
    var pass = document.getElementById('pass').value;

    var index = mailData.indexOf(email);
    if(index === 0)
        {
            ppp=10;
        }
    else
        {
            ppp=20;
        }
    if (index !== -1) {
        if (passData[index] === pass) {
            finalindex=index;
            window.open("finalPi.html");
        } else {
            alert("Password is wrong.");
        }
    } else {
        alert("Email not found.");
    }
}


// function regAdd(){
//     var email = document.getElementById('mail').value;
//     var pass = document.getElementById('pass').value;


//     if(mailData.includes(email)){
//         alert("this account alredy exist.");
//     }
//     else{

//         mailData.push(email);
//         passData.push(pass);

//     }

// }


var finalindex;
var totalBut = JSON.parse(localStorage.getItem('totalBut')) || [];
var mailData = JSON.parse(localStorage.getItem('mailData')) || [];
var passData = JSON.parse(localStorage.getItem('passData')) || [];
var field1 = JSON.parse(localStorage.getItem('budget4')) || [];
var field2 = JSON.parse(localStorage.getItem('budget4')) || [];
var field3 = JSON.parse(localStorage.getItem('budget4')) || [];
var field4 = JSON.parse(localStorage.getItem('budget4')) || [];
var budget1 = JSON.parse(localStorage.getItem('budget1')) || [];
var budget2 = JSON.parse(localStorage.getItem('budget2')) || [];
var budget3 = JSON.parse(localStorage.getItem('budget3')) || [];
var budget4 = JSON.parse(localStorage.getItem('budget4')) || [];

function regAdd(){
    var email = document.getElementById('mail').value;
    var pass = document.getElementById('pass').value;

    if(mailData.includes(email)){
        alert("This account already exists.");
    }
    else{
        mailData.push(email);
        passData.push(pass);
        localStorage.setItem('mailData', JSON.stringify(mailData));
        localStorage.setItem('passData', JSON.stringify(passData));
        window.open("butDetail.html");
    }
    
}
function fun2()
{
    var totalBut= [];
    var mailData = [];
    var passData = [];
    var field1 = [];
    var field2 = [];
    var field3 = [];
    var field4 = [];
    var budget1 = [];
    var budget2 = [];
    var budget3 = [];
    var budget4 = [];
    localStorage.setItem('totalBut', JSON.stringify([]));
    localStorage.setItem('mailData', JSON.stringify([]));
    localStorage.setItem('passData', JSON.stringify([]));
    localStorage.setItem('field1', JSON.stringify([]));
    localStorage.setItem('field2', JSON.stringify([]));
    localStorage.setItem('field3', JSON.stringify([]));
    localStorage.setItem('field4', JSON.stringify([]));
    localStorage.setItem('budget1', JSON.stringify([]));
    localStorage.setItem('budget2', JSON.stringify([]));
    localStorage.setItem('budget3', JSON.stringify([]));
    localStorage.setItem('budget4', JSON.stringify([]));
}
/////////////////////////////////////////////////////////////////////


function submit(){
    window.open('logPage.html');
    var t=parseFloat(document.getElementById('total').value);
    var f1=document.getElementById('fie1').value;
    var f2=document.getElementById('fie2').value;
    var f3=document.getElementById('fie3').value;
    var f4=document.getElementById('fie4').value;
    var b1=parseFloat(document.getElementById('amm1').value);
    var b2=parseFloat(document.getElementById('amm2').value);
    var b3=parseFloat(document.getElementById('amm3').value);
    var b4=parseFloat(document.getElementById('amm4').value);

    var m1=(b1/t)*100;
    var m2=(b2/t)*100;
    var m3=(b3/t)*100;
    var m4=(b4/t)*100;

    totalBut.push(t);
    field1.push(f1);
    field2.push(f2);
    field3.push(f3);
    field4.push(f4);
    budget1.push(m1);
    budget2.push(m2);
    budget3.push(m3);
    budget4.push(m4);

    localStorage.setItem('totalBut', JSON.stringify(totalBut));
    localStorage.setItem('field1', JSON.stringify(field1));
    localStorage.setItem('field2', JSON.stringify(field2));
    localStorage.setItem('field3', JSON.stringify(field3));
    localStorage.setItem('field4', JSON.stringify(field4));
    localStorage.setItem('budget1', JSON.stringify(budget1));
    localStorage.setItem('budget2', JSON.stringify(budget2));
    localStorage.setItem('budget3', JSON.stringify(budget3));
    localStorage.setItem('budget4', JSON.stringify(budget4));   
}

function fun3()
{
    if( ppp === 10)
    {
        window.open('Test4.html');
    }
    else
    {
        window.open('Text4.html');
    }
}

function final()
{
    window.open("logPage.html");
}

function fun4(){
    var nameDis = document.getElementById("lmao");
    nameDis.textContent=mailData[finalindex];
}
var ch="lode ka baal";
document.getElementById("chomu").innerHTML=ch;
