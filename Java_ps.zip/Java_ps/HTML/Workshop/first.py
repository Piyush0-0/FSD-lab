import pandas as pd
a=pd.read_csv('car_prediction_data.csv')
a.tail()
a.isnull().sum
