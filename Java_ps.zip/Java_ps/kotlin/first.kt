class first
{
    fun main()
    {
        println("hello piyush")
    }
}