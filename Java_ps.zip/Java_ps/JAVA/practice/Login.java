import javax.swing.*;
import java.awt.event.*;

public class Login extends JFrame implements ActionListener {
    
    public Login() {
        JFrame frame = new JFrame("RIT BANK");
        frame.setSize(400, 250);
        JLabel titleLabel = new JLabel("WELCOME TO RIT BANK");
        titleLabel.setBounds(100, 20, 200, 25); 
        frame.add(titleLabel);
		
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(50, 60, 80, 25);
        frame.add(usernameLabel);
		
        JTextField usernameField = new JTextField();
        usernameField.setBounds(140, 60, 200, 25);
        frame.add(usernameField);
		
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 100, 80, 25);
        frame.add(passwordLabel);
		
        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(140, 100, 200, 25);
        frame.add(passwordField);
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(100, 150, 80, 30);
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent a) {
                System.out.println("Login button clicked!"); // Debug statement
                // Implement your login logic here
                
                // Open the Select page
                JFrame selectFrame = new JFrame();
                selectFrame.setVisible(true); // Show the Select page
                
                // Dispose of the Login page
                frame.dispose();
            }
        });
        
        
        
        frame.add(loginButton);

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBounds(220, 150, 80, 30);
        frame.add(cancelButton);

        JButton signupButton = new JButton("Signup");
        signupButton.setBounds(160, 190, 80, 30);
        signupButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Signup button clicked!"); // Debug statement
                
                // Open the Signup page
                JFrame signupFrame = new JFrame();
                signupFrame.setVisible(true); // Show the Signup page
                
                // Dispose of the Login page
                frame.dispose();
            }
        });
        // Close the Login page after opening Signup
            
        
        frame.add(signupButton);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null); 
        frame.setVisible(true); 
    }

   
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Login()); 
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'actionPerformed'");
    }
}