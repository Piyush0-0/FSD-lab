//unique year
import java.util.Scanner;
public class practice10
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("ENter the year:");
        int p=sc.nextInt();
        for (int x=p+1;x<=9999;x++)
        {
            int w=0;
            String q=String.valueOf(x);
            for(int y=0;y<q.length()-1;y++)
            {
                for (int z=y+1;z<q.length();z++)
                {
                    if (q.charAt(y)==q.charAt(z))
                    {
                        w=1;
                    }
                }
            }
            if(w==0)
            {
                System.out.println(x);
                break;
            }
        }
    }
}