//group of talented kids
import java.util.Scanner;
public class practice9
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        Scanner mc=new Scanner(System.in);
        int x,m1=0,m2=0,m3=0,f,z;
        System.out.print("Enter the number of students:");
        z=sc.nextInt();
        System.out.print("Enetr the talents:");
        String p,q="";
        p=mc.nextLine();
        for (x=0;x<p.length();x++)
        {
            if (p.charAt(x)=='1')
                m1++;
            else if (p.charAt(x)=='2')
                m2++;
            else if (p.charAt(x)=='3')
                m3++;
            if (p.charAt(x)!=' ')
            {
                q+=p.charAt(x);
            }
        }
        if (m1<=m2)
        {
            if (m1<=m3)
                f=m1;
            else
                f=m3;
        }
        else
        {
            if(m2<=m3)
                f=m2;
            else
                f=m3;
        }
        System.out.println(f);
        int a[]=new int[10],b[]=new int[10],c[]=new int[10],x1=0,x2=0,x3=0;
        for(x=0;x<q.length();x++)
        {
            if (q.charAt(x)=='1')
            {
                a[x1]=x+1;
                x1++;
            }
            else if (q.charAt(x)=='2')
            {
                b[x2]=x+1;
                x2++;
            }
            else if (q.charAt(x)=='3')
            {
                c[x3]=x+1;
                x3++;
            }
        }
        for (x=0;x<f;x++)
        {
            System.out.println(a[x]+" "+b[x]+" "+c[x]);
        }
    }
}