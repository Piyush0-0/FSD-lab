//number of passed students
import java.util.Scanner;
public class practice4 
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int nk[]=new int[10],l[]=new int[10],count=0;
        int sum=0;
        System.out.print("enter:");
        for (int x=0;x<2;x++)
            nk[x]=sc.nextInt();
        for (int x=0;x<nk[0];x++)
        {
            l[x]=sc.nextInt();
            if (x==(nk[1]-1))
            {
                sum=l[x];
            }
        }
        for (int x=0;x<nk[0];x++)
        {
            if (l[x]>=sum)
                count++;
        }
        System.out.println(count);
    }
}