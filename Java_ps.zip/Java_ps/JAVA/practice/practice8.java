//boy or girl
import java.util.Scanner;
public class practice8
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the Name:");
        String p=sc.next();
        String q="";
        for (int x=0;x<p.length();x++)
        {
            int m=q.indexOf(p.charAt(x));
            if (m==-1)
                q+=p.charAt(x);
        }
        int w=q.length();
        if (w%2==0)
            System.out.println("CHAT WITH HER!");
        else
            System.out.println("Ignore Him");
    }
}