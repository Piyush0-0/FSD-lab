//players position
import java.util.Scanner;
public class practice7
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the position:");
        String p=sc.next();
        int q=p.indexOf("1111111");
        int r=p.indexOf("0000000");
        if (q!=-1 || r!=-1)
        {
            System.out.println("Yes");
        }
        else
            System.out.println("No");
    }
}