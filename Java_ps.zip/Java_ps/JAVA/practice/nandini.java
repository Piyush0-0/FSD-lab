import java.util.Scanner;
import java.lang.Math;
class nandini extends Thread
{
    void show(String w)
    {
        String p=w;
        for (int i=0;i<p.length();i++)
        {
            try
            {
                System.out.print(p.charAt(i));
                Thread.sleep(50);
            }
            catch(Exception m)
            {
                System.out.println("lol");
            }
        }    }
    void lol(String w)
    {
        double x;
        double y;
        for(y=0;y<25;y++)
        {
            double u=50-(y*y);
            x=Math.sqrt(u);
            if(x>0)
            {
                System.out.print("\033c");
                int i,j;
                for(i=0;i<x;i++)
                    System.out.print("\n");
                for(j=0;j<y;j++)
                    System.out.print("  ");
                System.out.print(w);
                try
                {
                    Thread.sleep(100);
                }
                catch(Exception m)
                {
                    System.out.println("lol");
                }
            }
        }
    }

    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        nandini s=new nandini();
        s.show("Enter a name:");
        String name=sc.next();
        s.lol(name);
    }
}