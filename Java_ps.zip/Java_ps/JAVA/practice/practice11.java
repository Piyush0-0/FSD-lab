//magnets 
import java.util.Scanner;
public class practice11
{
    public static void main(String args[])
    {
        Scanner sc= new Scanner(System.in);
        String p[]=new String[10];
        System.out.print("enter number of magnets:");
        int q=sc.nextInt();
        for (int x=0;x<q;x++)
        {
            p[x]=sc.next();
        }
        int t=1;
        for (int x=0;x<q-1;x++)
        {
            char r=p[x].charAt(0),s=p[x+1].charAt(0);
            if (r!=s)
            {
                t++;
            }
        }
        System.out.println(t);
    }
}