//lucky number
import java.util.Scanner;
public class practice6 
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int p;
        System.out.print("enter the number:");
        p=sc.nextInt();
        if (p%4==0 || p%7==0)
        {
            System.out.println("Yes");
        }
        else
        {
            String q=String.valueOf(p);
            for (int x=0;x<q.length();x++)
            {
                if (q.charAt(x)!='4' && q.charAt(x)!='7')
                {
                    System.out.println("NO");
                    return;
                }
            }
            System.out.println("Yes");
        }
    }
}