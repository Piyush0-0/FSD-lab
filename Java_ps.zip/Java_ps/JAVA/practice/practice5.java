//expression arranger
import java.util.Scanner;
public class practice5 
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the expression:");
        String p=sc.nextLine();
        int x,y,n=0,store[]=new int[100];
        store[0]=Integer.valueOf(p.charAt(0))-'0';
        for (x=0;x<p.length();x++)
        {
            if (p.charAt(x)=='+')
            {
                n++;
                store[n]=Integer.valueOf(p.charAt(x+1))-'0';
            }
        }
        for (x=0;x<n;x++)
        {
            for(y=x+1;y<=n;y++)
            {
                if (store[x]>store[y])
                {
                    int temp=store[x];
                    store[x]=store[y];
                    store[y]=temp;
                }
            }
        }
        String plus=" + ";
        String hehe="";
        for (x=0;x<=n;x++)
        {
            if (x!=n)
                hehe+=store[x]+plus;
            else
                hehe+=store[x];
        }
        System.out.println(hehe);
    }   
}