import java.util.Scanner;
class testcase extends Thread
{
    public static void main(String args[])
    {
        int m[]=new int[10];
        for (int x=0;x<10;x++)
            System.out.println(m[x]);
    }
}