import java.util.Scanner;
class SmallProject extends Thread
{
    void show(String w)
    {
        String p=w;
        for (int i=0;i<p.length();i++)
        {
            try
            {
                System.out.print(p.charAt(i));
                Thread.sleep(50);
            }
            catch(Exception m)
            {
                System.out.println("lol");
            }
        }    }
    void lol(String w)
    {
        int x,y;
        for(x=0;x<25;x++)
        {
            System.out.print("\033c");
            y=x+3;
            int i,j;
            for(i=0;i<x;i++)
                System.out.print("\n");
            for(j=0;j<y;j++)
                System.out.print("  ");
            System.out.print(w);
            try
            {
                Thread.sleep(100);
            }
            catch(Exception m)
            {
                System.out.println("lol");
            }
        }
    }

    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        SmallProject s=new SmallProject();
        s.show("Enter a name:");
        String name=sc.next();
        s.lol(name);
    }
}