//long string in short form
import java.util.Scanner;
class practice2
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int len,n,x;
        String p;
        System.out.print("enter the name:");
        p=sc.nextLine();
        len=p.length();
        System.out.println(len);
        if (len>=10)
        {
            char m=p.charAt(len-1),w=p.charAt(0);
            len-=2;
            String q=String.valueOf(w)+len+String.valueOf(m);
            System.out.println(q);
        }
        else
        {
            System.out.println(p);
        }
    }
}