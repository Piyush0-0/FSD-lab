import java.io.*;
import java.util.Scanner;
public class BigProject 
{
    public static void main (String args[])
    {
        int x;
        String com,h="";
        while(true)
        {
            Scanner sc=new Scanner(System.in);
            System.out.print("PS C:/Users/admin/Desktop >");
            while(true)
            {
                com=sc.nextLine();
                if (com.contains("copy con "))
                {
                    if (com.endsWith(".txt"))
                        break;
                    else
                    {
                        System.out.println("Invalid file type!!");
                        System.out.print("PS C:/Users/admin/Desktop >");
                    }
                }
                else
                {
                    System.out.println("Command not found!!!\n");
                    System.out.print("PS C:/Users/admin/Desktop >");
                }
            }
            String[] m=com.split(" ");
            String name=m[2];
            while(true)
            {
                String v=sc.nextLine();
                if (v=="")
                    break;
                else
                    h+=v+"\n";
            }
            try
            {
                FileWriter f=new FileWriter(name);
                f.write(h);
                System.out.println("Succesfully created");
                f.close();
            }
            catch(Exception e)
            {
                System.out.println("Error in creating file!!");
            }
        }
    }
}