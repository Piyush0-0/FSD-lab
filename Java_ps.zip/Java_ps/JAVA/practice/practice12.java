//orange juice
import java.util.Scanner;
public class practice12
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter number of drinks:");
        int t=sc.nextInt(),total=0;
        String p[]=new String[10];
        for (int x=0;x<t;x++)
        {
            p[x]=sc.next();
            int w=Integer.valueOf(p[x]);
            total+=w;
        }
        float d=total/t;
        System.out.println(d);

    }
}