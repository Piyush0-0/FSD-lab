//number of questions that three people can solve
import java.util.Scanner;
public class practice3 
{
    public static void main(String args[])
    {
        Scanner p=new Scanner(System.in);
        int count=0;
        int x[]=new int[10];
        System.out.print("enter number of questions:");
        int n=p.nextInt();
        for (int m=0;m<n;m++)
        {
            int count1=0;
            for (int w=0;w<3;w++)
            {
                x[m]=p.nextInt();
                if (x[m]==1)
                    count1++;
            }
            if (count1>=2)
                count++;
        }
        System.out.println(count);
    }
}