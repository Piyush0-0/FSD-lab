//long strings in short form
import java.util.Scanner;
class practice1
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int len,n,x;
        System.out.print("Enter number of words:");
        n=sc.nextInt();
        String p[]=new String[10];
        for (x=0;x<n;x++)
        {
            p[x]=sc.next();
        }
        for (x=0;x<n;x++)
        {
            len=p[x].length();
            if (len>=10)
            {
                char m=p[x].charAt(len-1),w=p[x].charAt(0);
                len-=2;
                String hola=String.valueOf(w)+len+String.valueOf(m);
                System.out.println(hola);
            }
            else
            {
                System.out.println(p[x]);
            }
        }
    }
}