class piyush
{
    int a[]=new int[3];
    int pos=0;
    void producer(int x)
    {
        if (pos==3)
        {
            System.out.println("Stack is full");
            try{wait();}
            catch(Exception e){}
        }
        else
        {
            System.out.println(x+" elemnt is produced");
            a[pos]=x;
            pos++;
            try{notify();}
            catch(Exception e){}
        }
    }
    void consumer()
    {
        if(pos==0)
        {
            System.out.println("STack is empty");
            try{wait();}
            catch(Exception e){}
        }
        else
        {
            pos--;
            System.out.println(a[pos]+" is consumed");
            try{notify();}
            catch(Exception e){}
        }
    }
}

class lol1 implements Runnable
{
    piyush x;
    Thread t;
    lol1(piyush s)
    {
        x=s;
        t=new Thread(this);
        t.start();
    }
    public void run()
    {
        for(int i=1;i<=5;i++)
        {
            x.producer(i);
            try{t.sleep(1000);}
            catch(Exception e){}
        }
    }
}
class lol2 implements Runnable
{
    piyush x;
    Thread t;
    lol2(piyush s)
    {
        x=s;
        t=new Thread(this);
        t.start();
    }
    public void run()
    {
        for(int i=1;i<=5;i++)
        {
            x.consumer();
            try{t.sleep(1000);}
            catch(Exception e){}
        }
    }
}
public class produce
{
    public static void main(String args[])
    {
        piyush p=new piyush();
        new lol1(p);
        new lol2(p);
    }
}
