import java.util.Scanner;
class pattern2
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the number:");
        int p=sc.nextInt();
        int m=(2*p)-1,x,y;
        int q[][]=new int[m][m];
        for(x=0;x<m;x++)
        {
            for(y=0;y<m;y++)
            {
                q[x][y]=0;
            }
        }
        q[0][p-1]=1;
        for(x=1;x<p;x++)
        {
            for(y=0;y<m-1;y++)
            {
                if (y>=1 || y<m-1)
                    q[x][y]=q[x-1][y-1]+q[x-1][y+1];
                else
                    q[x][y]=q[x-1][y]+q[x-1][y];

            }   
        }
        for(x=0;x<p;x++)
        {
            for(y=0;y<m;y++)
            {
                if(q[x][y]==0)
                System.out.print(' ');
                else
                System.out.print(q[x][y]);
            }
            System.out.print("\n");
        }
    }
}