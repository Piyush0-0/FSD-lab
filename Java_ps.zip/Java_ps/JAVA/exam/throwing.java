class piyush
{
    void lol()
    {
        System.out.println("Hello gay");
        try
        {
            lmao();
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }

    void lmao() throws Exception
    {
        throw new Exception("i am gay");
    }
}

public class throwing 
{
    public static void main(String args[])
    {
        piyush p=new piyush();
        p.lol();
    }
}
