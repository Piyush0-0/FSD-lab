import javax.swing.*;
import java.awt.*;

public class layout {

    public static void main(String[] args) {
        // Create the frame
        JFrame frame = new JFrame("Layout Manager Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        // Create buttons for BorderLayout
        JButton buttonNorth = new JButton("North");
        JButton buttonSouth = new JButton("South");
        JButton buttonEast = new JButton("East");
        JButton buttonWest = new JButton("West");
        JButton buttonCenter = new JButton("Center");

        // Create buttons for GridLayout
        JButton buttonA = new JButton("Button A");
        JButton buttonB = new JButton("Button B");
        JButton buttonC = new JButton("Button C");
        JButton buttonD = new JButton("Button D");

        // Create buttons for FlowLayout
        JButton button1 = new JButton("Button 1");
        JButton button2 = new JButton("Button 2");
        JButton button3 = new JButton("Button 3");
        JButton button4 = new JButton("Button 4");
        JButton button5 = new JButton("Button 5");

        // BorderLayout Example
        frame.setLayout(new BorderLayout());
        frame.add(buttonNorth, BorderLayout.NORTH);
        frame.add(buttonSouth, BorderLayout.SOUTH);
        frame.add(buttonEast, BorderLayout.EAST);
        frame.add(buttonWest, BorderLayout.WEST);
        frame.add(buttonCenter, BorderLayout.CENTER);

        // Display the frame
        frame.setVisible(true);

        // Sleep for 2 seconds to show BorderLayout before changing to GridLayout
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // GridLayout Example
        frame.getContentPane().removeAll(); // Clear previous layout
        frame.setLayout(new GridLayout(2, 2));
        frame.add(buttonA);
        frame.add(buttonB);
        frame.add(buttonC);
        frame.add(buttonD);

        // Refresh the frame
        frame.revalidate();
        frame.repaint();

        // Sleep for 2 seconds to show GridLayout before changing to FlowLayout
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // FlowLayout Example
        frame.getContentPane().removeAll(); // Clear previous layout
        frame.setLayout(new FlowLayout());
        frame.add(button1);
        frame.add(button2);
        frame.add(button3);
        frame.add(button4);
        frame.add(button5);

        // Refresh the frame
        frame.revalidate();
        frame.repaint();
    }
}