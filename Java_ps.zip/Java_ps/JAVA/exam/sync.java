class piyush extends Thread
{
    String name;
    piyush(String s)
    {
        this.name=s;
    }
    public void run()
    {
        System.out.println(this.name+" is running");
        System.out.println(this.name+" is exiting");
    }
}

public class sync 
{
    public static void main(String args[])
    {
        piyush p=new piyush("one");
        piyush q=new piyush("two");
        piyush r=new piyush("three");
        p.setPriority(4);
        q.setPriority(5);
        r.setPriority(6);
        p.start();
        q.start();
        r.start();
    }
}
