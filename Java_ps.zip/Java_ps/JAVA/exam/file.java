import java.io.*;
import java.util.Scanner;
class file 
{
    public static void main(String args[])
    {
        try
        {
            // File m=new File("piyush.txt");
            Scanner sc= new Scanner(System.in);
            String mm="HEllo gays";
            FileWriter p=new FileWriter("piyush.txt");
            p.write(mm);
            p.close();
            FileReader r=new FileReader("piyush.txt");
            int v;
            while((v=r.read())!=-1)
            {
                if((char)v=='\n')
                {
                    String x=sc.nextLine();
                }
                else
                {
                    System.out.print((char)v);
                }
            }
            r.close();
        }
        catch(Exception e){}
    }    
}
