public class jdbc 
{
    public static void main(String args[])
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306:/student","root","1234");
            Statement s=con.createStatement();
            ResultSet rs=s.executeQuery("Select * from student");
            while(rs.next())
                System.out.println(rs.getInt(1)+""+rs.getString(2)+""+rs.getInt(3)+"");
            con.close();
        }
        catch(Exception e){}
    }    
}
        