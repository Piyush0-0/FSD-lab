import java.util.Scanner;
class item 
{

}
public class Shop 
{
    public static void main(String args[])
    {
        String p[]=new String[10];
        Scanner q=new Scanner(System.in);
        int a,b;
        String s="piyush";
        int m=Integer.valueOf(s);
        System.out.println(m);

    }
}
