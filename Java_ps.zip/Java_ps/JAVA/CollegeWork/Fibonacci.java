import java.util.Scanner;
class Fibonacci
{
    public static void main(String args[])
    {
        int a,b=0,c=1;
        Scanner p=new Scanner(System.in);
        System.out.print("Enter number of series:");
        a=p.nextInt();
        Fibonacci m=new Fibonacci();
        System.out.println(b);
        System.out.println(c);
        m.lol(b,c,a-2);
    }
    void lol(int a,int b, int c)
    {
        Fibonacci m=new Fibonacci();
        if (c==1)
        {
            System.out.println(a+b);
        }
        else
        {
            System.out.println(a+b);
            m.lol(b,a+b,c-1);
        }
    }
}