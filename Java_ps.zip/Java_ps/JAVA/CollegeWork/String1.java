import java.util.Scanner;
public class String1
{
    public static void main(String args[])
    {
        int i,j,k;
        int f[]=new int[100];
        char d[]=new char[100];
        String e;
        Scanner n=new Scanner(System.in);
        System.out.print("Enter the names:");
        e=n.nextLine();
        for (i=0;i<e.length();i++)
        {
            d[i]=e.charAt(i);
        }
        int w=e.length();
        j=0;
        f[0]=0;
        for(i=0;i<e.length();i++)
        {
            if (d[i]==' ')
            {
                j++;
                f[j]=i+1;
            }
        }
        for (i=0;i<=j;i++)
        {
            for (k=i+1;k<=j;k++)
            {
                int huh=f[i],haha=f[k];
                if(d[huh]==d[haha])
                {
                    int a=huh,b=haha;
                    while (d[a]==d[b])
                    {
                        a++;
                        b++;
                    }
                    if (d[a]>d[b])
                    {
                        int x;
                        x=f[i];
                        f[i]=f[k];
                        f[k]=x;
                    }
                }
                else if (d[huh]>d[haha])
                {
                    int x;
                    x=f[i];
                    f[i]=f[k];
                    f[k]=x;
                }
            }
        }
        d[w]=' ';
        for (i=0;i<=j;i++)
        {
            int v=f[i];
            while (d[v]!=' ')
            {
                System.out.print(d[v]);
                v++;
            }
            System.out.print("\n");
        }
    }
}