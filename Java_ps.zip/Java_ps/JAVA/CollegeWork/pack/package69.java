package pack;

public class package69
{
        public void lol(int x)
        {
            int i,j,k;
            System.out.print("enter the number:");
            k=x;
            for (i=1;i<=k;i++)
            {
                for (j=0;j<(k-i);j++)
                {
                    System.out.print(" ");
                }
                j=i;
                while (j>0)
                {
                    System.out.print(i+" ");
                    j--;
                }
                System.out.print("\n");
            }
        }
}
