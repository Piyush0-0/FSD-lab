class Piyush
{
    void lol()
    {
        System.out.println("HEllo");
    }
    class Akhil
    {
        void lmao()
        {
            System.out.println("HEllo boy");
        }
    }
}
public class inner
{
    public static void main(String args[])
    {
        System.out.println("Hmm...");
        Piyush p=new Piyush();
        Piyush.Akhil a=p.new Akhil();
        p.lol();
        a.lmao();
    }
}