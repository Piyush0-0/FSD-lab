import java.util.Scanner;
public class Number
{
    public static void main(String args[])
    {
        Scanner p=new Scanner(System.in);
        String m;
        while (true)
        {
            System.out.print("enter a number:");
            m=p.nextLine();
            int a=m.length();
            if (a>4)
            {
                System.out.println("Enter only upto 4 digits");
            }
            else
            {
                break;
            }
        }
        int k=Integer.valueOf(m);
        String n=String.valueOf(k);
        Mama pp=new Mama();
        int l=n.length();
        if (k==0)
        {
            System.out.println("Zero");
        }
        else if (l==1)
        {
            pp.one(n);
        }
        else if (l==2)
        {
            pp.two(n);
        }
        else if (l==3)
        {
            pp.three(n);
        }
        else if (l==4)
        {
            pp.four(n);
        }
    }
}
class Mama
{
    static String x[]={"one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","ninteen"};
    static String y[]={"twenty","thirty","fourty","fifty","sixty","seventy","eighty","ninty"};
    static String z="";
    void one(String p)
    {
        char n=p.charAt(0);
        int m=n-'0';
        z=z+x[m-1];
        System.out.println(z);
    }
    void two(String p)
    {
        char h=p.charAt(0);
        int j=h-'0';
        if (j<2)
        {
            int m=Integer.valueOf(p);
            if (m!=0)
            {
                z=z+x[m-1];
            }
        }
        else
        {
            int m=p.charAt(0)-'0';
            int n=p.charAt(1)-'0';
            z=z+y[m-2]+' ';
            if (n!=0)
            {
                z+=x[n-1];
            }
        }
        System.out.println(z);
    }
    void three(String p)
    {
        int m=(p.charAt(0)-'0');
        if (m!=0)
        {
            z+=x[m-1]+" hundred ";
        }
        String n=String.valueOf(p.charAt(1))+String.valueOf(p.charAt(2));
        Mama u=new Mama();
        z+="and ";
        u.two(n);
    }
    void four(String p)
    {
        int m=(p.charAt(0)-'0');
        z+=x[m-1]+" thousand ";
        String n=String.valueOf(p.charAt(1))+String.valueOf(p.charAt(2))+String.valueOf(p.charAt(3));
        Mama u=new Mama();
        u.three(n);   
    }
}
