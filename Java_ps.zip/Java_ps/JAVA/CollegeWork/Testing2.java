import java.util.Scanner;
class Testing2
{
    public static void main(String args[])
    {
        Scanner p=new Scanner(System.in);
        String m[]=new String[10];
        for (int x=0;x<3;x++)
        {
            m[x]=p.next();
        }
        for (int x=0;x<3;x++)
        {
            System.out.println(m[x]);
        }
    }
}