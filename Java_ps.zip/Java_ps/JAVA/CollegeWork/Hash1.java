import java.util.*;
class Hash1
{
    public static void main(String args[])
    {
        Hashtable<String,Integer> p=new Hashtable<String,Integer>();
        p.put("piyush",69);
        p.put("gopi",23);
        p.put("akhil",96);
        p.put("mayur",6);
        for (Map.Entry m:p.entrySet())
        {
            System.out.println(m.getKey() +" "+m.getValue());
        }
        p.remove("piyush");
        System.out.println(p.getOrDefault("gopi", 78));
        p.putIfAbsent("alanya",143);
        System.out.println(p);
    }
}