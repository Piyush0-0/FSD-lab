class lol
{
    lol(int x)
    {
        System.out.println("x="+x);
    }
    final void lmao()
    {
        System.out.println("hello");
    }
}
class haha extends lol
{
    haha(int a,int b)
    {
        super(b);
        System.out.println(a);
        lmao();        
    }
}
class Ultimate
{
    public static void main(String args[])
    {
        haha p=new haha(10,20);
    }
} 