import java.util.Scanner;
public class Inbuild 
{
    public static void main(String args[])

    {
        System.out.println("Welcome to The Office");
        Scanner p=new Scanner(System.in);
        String age;
        String name,department;
        System.out.print("Enter Employee Name:");
        name=p.nextLine();
        System.out.print("Enter Employee Age:");
        age=p.nextLine();
        System.out.print("Enter Employee Department:");
        department=p.nextLine();
        System.out.println("The Details Are.......");
        System.out.println("Name="+name);
        System.out.println("Age="+age);
        System.out.println("Department="+department);
    }
}
