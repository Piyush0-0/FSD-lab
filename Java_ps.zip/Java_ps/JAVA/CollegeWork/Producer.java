class lol
{
    lol l=new lol();
    int arr[]=new int[10],c=0;
    void produce(int x)
    {
        if (c==2)
        {
            try
            {
                wait();
            }
            catch(Exception e){}
        }
        else
        {
            arr[c]=x;
            c++;
            notify();
        }
    }
    void consume()
    {
        if (c==0)
        {
            try
            {
                wait();
            }
            catch(Exception e){}
        }
        else
        {
            System.out.println(" was consumed"+arr[c]);
            c--;
            notify();
        }
    }
}
class consume extends lol
{
    int m;
    consume(int n)
    {
        m=n;
        Thread f=new Thread();
        f.start();
    }
    public void run()
    {
        for (int x=0;x<m;x++)
            l.consume();
    }
}
class produce extends lol
{
    int[] h;
    produce(int m[])
    {
        h=m;
        Thread f=new Thread();
        f.start();
    }
    public void run()
    {
        for (int x=0;x<h.length;x++)
            l.produce(h[x]);
    }
}
public class Producer 
{
    public static void main(String args[])
    {
        System.out.println("This is producer consumer problem.");
        int w[]=new int[]{2,3,4,6,5};
        produce p=new produce(w);
        consume q=new consume(5);
    }    
}       