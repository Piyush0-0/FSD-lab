abstract class Shape
{
    int a,b;
    abstract void printArea();
}
class Rectangle extends Shape
{
    void printArea()
    {
        int a=5,b=6;
        System.out.println("Area of rectangle is "+(a*b));
    }
}
class Circle extends Shape
{
    void printArea()
    {
        int a=5;
        System.out.println("Area of circle is "+(3.14*a*a));
    }
}
class Triangle extends Shape
{
    void printArea()
    {
        int a=5;
        System.out.println("Area of Triangle is "+(a*a)/2f);
    }
}
class Main
{public static void main(String args[])
    {
        Rectangle p=new Rectangle();
        Circle q=new Circle();
        Triangle r=new Triangle();
        p.printArea();
        q.printArea();
        r.printArea();
    }
}