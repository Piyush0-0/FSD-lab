interface piyush
{
    void lol(int x);
}
public class Lambda
{
    public static void main(String args[])
    {
        piyush p=(int x)->{System.out.println("hello");};
        p.lol(20);
    }
}