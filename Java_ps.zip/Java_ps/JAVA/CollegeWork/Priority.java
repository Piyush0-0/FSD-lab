
 
// Main class
class Priority extends Thread 
{
    String n;
    Priority(String m)
    {
        this.n=m;
    }
    public void run()
    {
        System.out.println("Inside run method " + Thread.currentThread().getName()+" "+n);
    }
 
    
    public static void main(String[] args)
    {
        Priority t1 = new Priority("piyush");
        Priority t2 = new Priority("gopi");
        Priority t3 = new Priority("akhil");
 
        System.out.println("t1 thread Priority : " + t1.getPriority());
 
        System.out.println("t2 thread Priority : " + t2.getPriority());
 
        System.out.println("t3 thread Priority : " + t3.getPriority());
 
        t1.setPriority(6);
        t2.setPriority(1);
        t3.setPriority(8);
		t1.start();
		t2.start();
		t3.start();
 
        // Main threadDisplays the name of currently executing Thread
        // System.out.println("Currently Executing Thread : "+ Thread.currentThread().getName());
 
        // System.out.println("Main thread Priority : "+ Thread.currentThread().getPriority());
    }
}
