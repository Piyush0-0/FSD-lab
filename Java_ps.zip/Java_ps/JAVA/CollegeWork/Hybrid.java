interface Piyush
{
    void lol();
}
interface Mayur
{
    void lmao();
}
class Naruto implements Piyush,Mayur
{
    public void lol()
    {
        System.out.println("hello piyush");
    }
    public void lmao()
    {
        System.out.println("hello Mayur");
    }
}
class Sasuke extends Naruto
{
    void huh()
    {
        System.out.println("hello gopi");
    }
}
class Itachi extends Naruto
{
    void heh()
    {
        System.out.println("hello akhil");
    }
}
public class Hybrid 
{
    public static void main(String arga[])
    {
        Sasuke p=new Sasuke();
        Itachi q=new Itachi();
        p.lol();
        p.lmao();
        p.huh();
        q.lol();
        q.lmao();
        q.heh();
    }
}