import java.util.Random;
import java.util.Scanner;
public class Match 
{
void BatFirst(int ov) 
    {
        System.out.println("#### MATCH START ####");
        Scanner sc = new Scanner(System.in);
        Random ra = new Random();
        int tsc = 0; 
        int csc=0;
        int bs, bo;
        System.out.println("Player Batting");
        for (int i = 0; i < ov; i++)
        {
            System.out.println("Over " + (i + 1));
            for (int ba = 0; ba < 6; ba++) 
            {
                System.out.println("Enter Runs:");
                bs = sc.nextInt();
                if (bs > 6)
                {
                    System.out.println("Enter Between 0 to 6");
                    break;
                }
                bo = ra.nextInt(7); 
                System.out.println("Computer Bowl: " + bo);
                if (bs == bo) 
                {
                    System.out.println("!!! OUT !!!");
                    
                }
                else 
                {
                    tsc =tsc+bs;
                }
            }
            System.out.println("Total Score: " + tsc);
        }
        System.out.println("Runs To Defend For Player :"+tsc);
        System.out.println("Runs To Chase For Computer :"+tsc);
        System.out.println("         In Overs"+ov);
        System.out.println("Player Bowls");
        for(int i=0;i<ov;i++)
        {
            System.out.println("Over " + (i + 1));
            for (int ba = 0; ba < 6; ba++) 
            {
                 System.out.println("Enter Runs:");
                bs = sc.nextInt();
                if (bs > 6)
                {
                    System.out.println("Enter Between 0 to 6");
                    break;
                }
                bo = ra.nextInt(7); 
                System.out.println("Computer Bat: " + bo);
                if (bs == bo) 
                {
                    System.out.println("!!! OUT !!!");
                    
                }
                else 
                {
                    csc =csc+bs;
                    if(csc>tsc)
                    {
                        System.out.println("#### Taget Chased ####");
                        System.out.println("Chasing Team Won");
                        System.out.println("AUSTRALIA YOU BEAUTY CHASED THE TARGET EASILY AND GOT OVER INDIA TO LIFT THE WORLD CUP");
                        System.exit(0);
                    }
                    else
                    {
                        
                        continue;
                    }
                }
            }
            if(csc>tsc)
            {
                System.out.println("#### Taget Chased ####");
                System.out.println("Chasing Team Won");
                System.out.println("AUSTRALIA YOU BEAUTY CHASED THE TARGET EASILY AND GOT OVER INDIA TO LIFT THE WORLD CUP");
                System.exit(0);
            }
            else
            {
                if(csc == tsc)
                {
                    System.out.println("!!! DRAW MATCH !!!");
                }
                else
                {
                    continue;
                }
            }
        }
        
        
        
    }
    void BowlFirst(int ov)
    {
        Scanner sc = new Scanner(System.in);
        Random ra = new Random();
        int tsc=0;
        int csc=0;
        int bo,bs,i;
        System.out.println("Computer Batting");
        for(i=0;i<ov;i++)
        {
            System.out.println("Over " + (i + 1));
            for (int ba = 0; ba < 6; ba++) 
            {
                System.out.println("Enter Runs:");
                bs = sc.nextInt();
                if (bs > 6)
                {
                    System.out.println("Enter Between 0 to 6");
                    break;
                }
                bo = ra.nextInt(7); 
                System.out.println("Computer Bat: " + bo);
                if (bs == bo) 
                {
                    System.out.println("!!! OUT !!!");
                }
                else 
                {
                    tsc =tsc+bo;
                }
            }
            System.out.println("Total Score: " + tsc);
        }
        System.out.println("Runs To Defend For Computer :"+tsc);
        System.out.println("Runs To Chase For Player :"+tsc);
        System.out.println("         In Overs"+ov);
        System.out.println("Player Bats");
        for(i=0;i<ov;i++)
        {
            System.out.println("Over " + (i + 1));
            for (int ba = 0; ba < 6; ba++) 
            {
                 System.out.println("Enter Runs:");
                bs = sc.nextInt();
                if (bs > 6)
                {
                    System.out.println("Enter Between 0 to 6");
                    break;
                }
                bo = ra.nextInt(7); 
                System.out.println("Computer Bowl: " + bo);
                if (bs == bo) 
                {
                    System.out.println("!!! OUT !!!");
                }
                else 
                {
                    csc =csc+bs;
                    if(csc>tsc)
                    {
                        System.out.println("#### Taget Chased ####");
                        System.out.println("Chasing Team Won");
                        System.out.println("INDIA YOU BEAUTY CHASED THE TARGET EASILY AND GOT OVER AUSTRALIA TO LIFT THE WORLD CUP");
                        System.exit(0);
                    }
                    else
                    {
                        
                        continue;
                    }
                }
            }
            if(csc>tsc)
            {
                System.out.println("#### Taget Chased ####");
                System.out.println("Chasing Team Won");
                System.out.println("INDIA YOU BEAUTY CHASED THE TARGET EASILY AND GOT OVER AUSTRALIA TO LIFT THE WORLD CUP");
                System.exit(0);
            }
            else
            {
                if(csc == tsc)
                {
                    System.out.println("!!! DRAW MATCH !!!");
                }
                else
                {
                    continue;
                }
            }
        }
        
    }
    

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        Match obj = new Match();
        System.out.println("** WELCOME TO THE FINAL OF WORLD CUP 2023 **");
        System.out.println("                INDIA ");
        System.out.println("                 V/S   ");
        System.out.println("              AUSTRALIA ");
        System.out.println("Enter Number Of Overs:");
        int x = sc.nextInt();
        ////////////////////////
        String res,call,Ca;
        String[] toss;
        toss = new String[2];
        toss[0]="HEAD";
        toss[1]="TAIL";
        Random c = new Random();
        Scanner a =new Scanner(System.in);
        int coin;
        System.out.println("ITS TOSS TIME");
        System.out.println(" Coin Tossed ");
        System.out.println("INDIA CALLS FOR :");
        call=a.nextLine();
        
        coin=c.nextInt(2);
        
        res=toss[coin];
        System.out.println("SHOWLKHLK  " +res);
        if (call.equalsIgnoreCase(res))
        {
            System.out.println("ITS "+res);
            System.out.println("INDIA HAS WON THE TOSS");
            int de;
            System.out.println("Whats does INDIA want to do");
            System.out.println("1:Batting");
            System.out.println("2:Bowling");
            de = a.nextInt();
            switch(de)
            {
                case 1:
                    System.out.println("INDIA ELECTS TO BAT FIRST");
                    //obj.BatFirst(x);
                    break;
                case 2:
                    System.out.println("INDIA ELECTS TO BOWL FIRST");
                    //obj.BowlFirst(x);
                    break;
                default:
                System.out.println("Enter Valid decision");
            }
        }
        else
        {
            int ho;
            String sl;
            System.out.println("ITS "+res); 
            System.out.println("AUSTRALIA HAS WON THE TOSS");
            String[] dec;
            dec =new String[2];
            dec[0]="Batting";
            dec[1]="Bowling";
            ho=c.nextInt(2);
            sl=dec[ho];
            if(sl=="Batting")
            {
                System.out.println("AUSTRALIA ELECTS TO BAT FIRST");
                obj.BatFirst(x);
            }
            if(sl=="Bowling")
                System.out.println("AUSTRALIA ELECTS TO BOWL FIRST"); 
                obj.BowlFirst(x);  
        }
    }
}