class Piyush extends Thread
{
    String name;
    Piyush(String n)
    {
        this.name=n;
    }
    public void run()
    {
        try
        {
            Thread.sleep(2000);
            System.out.println(name+":Hello");
        }
        catch(Exception e)
        {
            System.out.println("Thread "+name+" is intrupted" );
        }
    }
}
public class MultiThread 
{
    public static void main(String args[])
    {
        Piyush p=new Piyush("gopi");
        Piyush q=new Piyush("akhil");
        Piyush r=new Piyush("mayur");
        p.start();
        q.start();
        r.start();
        try
        {
            q.interrupt();
        }
        catch(Exception e)
        {
            System.out.println("ok");
        }
    }
}