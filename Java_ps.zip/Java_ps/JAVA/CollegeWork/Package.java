import pack.package69;
public class Package
{
    public static void main(String args[])
    {
        package69 p=new package69();
        p.lol(5);
    }
}