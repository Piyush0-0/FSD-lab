import java.util.Scanner;
public class Factorial 
{
    public static void main(String arge[]) 
    {
        int a,c,b=1;
        Scanner p=new Scanner(System.in);
        System.out.print("Enter teh number:");
        a=p.nextInt();
        c=a;
        while (a>=1)
        {
            b=b*a;
            a--;
        }
        System.out.println("The factorial of "+c+" is "+b);
    }   
}
