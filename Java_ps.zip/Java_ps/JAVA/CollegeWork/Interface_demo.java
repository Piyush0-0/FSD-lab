interface Piyush
{
    void lol();
}
class Mayur implements Piyush
{
    public void lol()
    {
        System.out.println("hello");
    }
}
public class Interface_demo
{
    public static void main(String args[])
    {
        Mayur m=new Mayur();
        m.lol();
    }
}
