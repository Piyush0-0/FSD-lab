import os
import requests
p=requests.get("http://youtube.com")
print(p)